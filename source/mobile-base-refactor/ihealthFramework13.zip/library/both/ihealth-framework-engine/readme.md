
##Engine for iHealth Framework
This package is required by the mobile and web framework. It contains common react components; necessary CSS; and JS files for both the web and mobile framework.
