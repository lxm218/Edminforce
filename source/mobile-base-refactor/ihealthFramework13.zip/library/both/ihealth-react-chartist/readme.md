
##Chartist for React
Install this package to use Chartist in your app.
