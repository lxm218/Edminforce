
ChatDispatcher = new MeteorFlux.Dispatcher();
