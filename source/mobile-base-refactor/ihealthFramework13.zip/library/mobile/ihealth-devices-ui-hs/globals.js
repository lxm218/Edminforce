if (typeof(this.DeviceRC) === 'undefined') this.DeviceRC = {}
if (typeof(DeviceRC === 'undefined')) DeviceRC = this.DeviceRC
