
## Standard Units in Measurements and UserInfo

  Name           | Unit
  ------------   | ------
__HeightUnit__   | cm
__WeightUnit__   | kg
__BPUnit__       | mmHg
__BGUnit__       | mg/dl
__FoodUnit__     | g
__DistanceUnit__ | km