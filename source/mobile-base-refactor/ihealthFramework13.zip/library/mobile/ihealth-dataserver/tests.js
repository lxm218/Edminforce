
//var bp = {
//  "UUID" : "r4EpbbviXMCL8wcsm",
//  "LP" : 85,
//  "deviceAddress" : "8CDE521448F0",
//  "deviceModel" : "BP5",
//  "HR" : 63,
//  "FP" : 136,
//  "FW" : [ 19, 19, 19, 19, 18, 18, 18, 18 ],
//  "HP" : 115,
//  "MDateUTC" : new Date("2015-09-07T02:34:57.954Z"),
//  "UID" : "zCi9zbtCMBZNMEYcS",
//  "deviceType" : "BP",
//  "createdAt" : new Date("2015-09-07T02:34:57.965Z"),
//  "TimeZone": "-0700",
//  "BPUnit": 0
//};