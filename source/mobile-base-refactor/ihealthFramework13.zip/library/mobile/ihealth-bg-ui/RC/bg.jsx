
IH.Device.BGLayout = class extends IH.Device.Layout {}
IH.Device.BGLayout.displayName = "BGLayout"
