iGluco.Progress = React.createClass({
  render() {
    return <div id="primaryContainer" className="primaryContainer clearfix">
      <div id="PhoneContainer" className="">
        <HeaderNav />
        <Icons />
        <HelpPanel />
        <FooterButton />
      </div>
    </div>
  }
});
