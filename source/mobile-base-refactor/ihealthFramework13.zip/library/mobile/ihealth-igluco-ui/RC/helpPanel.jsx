
HelpPanel = React.createClass({
  render() {
    return <div id="HelpPanel" className="">
      <p id="HelpText">
        Turn on the meter
      </p>
      <div id="InstructMeterOn" className="clearfix">
        <p id="_3s’_copy">
          3s’
        </p>
      </div>
      <BigButtons />
    </div>
  }
});
