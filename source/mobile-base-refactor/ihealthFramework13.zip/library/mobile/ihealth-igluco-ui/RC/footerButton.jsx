
FooterButton = React.createClass({
  render() {
    return <div className="footer">
      <div id="FooterButton" className="clearfix">
        <img id="PencilIcon" src="img/pencil%20icon%20copy%203.png" className="image" />
        <p id="ButtonText">
          Manually input your measurement
        </p>
      </div>
    </div>
  }
});
