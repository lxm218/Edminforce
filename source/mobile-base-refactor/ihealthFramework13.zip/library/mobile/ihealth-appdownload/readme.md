
##iHealth Devices - React Components
This packages gives you react components that can be used together with iHealth Device JS Classes.
