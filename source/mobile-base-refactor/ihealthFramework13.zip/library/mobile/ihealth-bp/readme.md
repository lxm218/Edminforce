
##iHealth BP5 Javascript Class
This package gives you a iHealthBP5 variable that you can use together with the BP5 Cordova Plugin.
